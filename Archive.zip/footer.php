 <!-- start footer --> 
        <footer class="footer-strip-dark bg-black padding-50px-tb xs-padding-30px-tb">
            <div class="container">
                <div class="row equalize xs-equalize-auto">
                    <!-- start logo -->
                    <div class="col-md-3 col-sm-3 col-xs-12 display-table sm-text-center xs-margin-20px-bottom">
                        <div class="display-table-cell vertical-align-middle">
                            <a href="./index.php"><text class="text-center text-extra-large text-white"> <b class="alt-font">AEGIS FIRE</b> </text></a>
                        </div>
                    </div> 
                    <!-- end logo -->
                    <!-- start copyright -->
                    <div class="col-md-6 col-sm-6 col-xs-12 text-center text-small alt-font display-table xs-margin-10px-bottom">
                        <div class="display-table-cell vertical-align-middle">
                            &copy; AEGIS FIRE Web, Developed by <a href="#" target="_blank" title="ThemeZaa">Pixiverse</a>.
                        </div>
                    </div>
                    <!-- end copyright -->
                    <!-- start social media -->
                    <div class="col-md-3 col-sm-3 col-xs-12 display-table text-right sm-text-center">
                        <div class="display-table-cell vertical-align-middle">
                            <div class="social-icon-style-8 display-inline-block vertical-align-middle">
                                <ul class="small-icon no-margin-bottom">
                                    <li><a class="facebook text-white" href="https://www.facebook.com/" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                    <li><a class="twitter text-white" href="https://twitter.com/" target="_blank"><i class="fa fa-twitter"></i></a></li>
                                    <li><a class="google text-white" href="https://plus.google.com" target="_blank"><i class="fa fa-google-plus"></i></a></li>
                                    <li><a class="instagram text-white" href="https://instagram.com/" target="_blank"><i class="fa fa-instagram no-margin-right" aria-hidden="true"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <!-- end social media -->
                </div>
            </div>
        </footer>
        <!-- end footer -->